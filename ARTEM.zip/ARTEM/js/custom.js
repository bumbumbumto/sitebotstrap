$(document).ready(function(){
	$('.navbar-toggler-icon').click(function(){
		$('.navbar-toggler-icon').toggleClass('active');
	})
})